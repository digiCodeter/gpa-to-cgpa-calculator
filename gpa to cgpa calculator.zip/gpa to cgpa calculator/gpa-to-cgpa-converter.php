<?php
/*
Plugin Name: GPA to CGPA Converter
Plugin URI: http://yourwebsite.com/gpa-to-cgpa-converter
Description: A plugin to convert GPA to CGPA.
Version: 1.0
Author: Arsalan khan
*/

// Ensure the file is being called by WordPress
defined('ABSPATH') or die('No script kiddies please!');

// Register a shortcode
function gpa_to_cgpa_converter_shortcode() {
    ob_start();
    ?>
    <div id="gpa-to-cgpa-converter">
        <form id="converter-form">
	    <h2>GPA to CGPA Calculator</h2>
            <div id="gpa-fields">
                <div class="gpa-field">
                    <label for="gpa1">Semester 1 GPA:</label>
                    <input type="number" id="gpa1" name="gpa[]" step="0.01" min="0" max="10" required>
                    <label for="credit1">Credit Hours:</label>
                    <input type="number" id="credit1" name="credit[]" step="0.5" min="1" required>
                    <div id="empty-div"></div>
                </div>
            </div>
            <div class="button-row">
                <button type="button" id="add-field">Add Another Semester</button>
                <button type="submit">Calculate CGPA</button>
            </div>
        </form>
        <label id="result-label" for="cgpa-result">Result:</label>
        <input type="text" id="cgpa-result" disabled="true" placeholder="Your CGPA">
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var fieldCounter = 1;

            document.getElementById('add-field').addEventListener('click', function() {
                fieldCounter++;
                var gpaFields = document.getElementById('gpa-fields');
                var newField = document.createElement('div');
                newField.classList.add('gpa-field');
                newField.innerHTML = `
                    <label for="gpa${fieldCounter}">Semester ${fieldCounter} GPA:</label>
                    <input type="number" id="gpa${fieldCounter}" name="gpa[]" step="0.01" min="0" max="10" required>
                    <label for="credit${fieldCounter}">Credit Hours:</label>
                    <input type="number" id="credit${fieldCounter}" name="credit[]" step="0.5" min="1" required>
                    <button type="button" class="remove-field">Remove</button> <!-- Remove button added here -->
                `;
                gpaFields.appendChild(newField);

                // Add event listener for remove button
                newField.querySelector('.remove-field').addEventListener('click', function() {
                    gpaFields.removeChild(newField);
                });
            });

            document.getElementById('converter-form').addEventListener('submit', function(event) {
                event.preventDefault();
                
                var gpaInputs = document.querySelectorAll('input[name="gpa[]"]');
                var creditInputs = document.querySelectorAll('input[name="credit[]"]');
                var totalPoints = 0;
                var totalCredits = 0;
                var isValid = true;

                gpaInputs.forEach(function(input, index) {
                    var gpa = parseFloat(input.value);
                    var credit = parseFloat(creditInputs[index].value);

                    if (isNaN(gpa) || gpa < 0 || gpa > 10 || isNaN(credit) || credit < 1) {
                        isValid = false;
                        return;
                    }

                    totalPoints += gpa * credit;
                    totalCredits += credit;
                });

                if (!isValid) {
                    document.getElementById('cgpa-result').innerText = 'Please enter valid GPA and Credit Hours values.';
                    document.getElementById('cgpa-result').style.color = 'red';
                    return;
                }

                var cgpa = totalPoints / totalCredits;
                document.getElementById('cgpa-result').value = `Your CGPA is ${cgpa.toFixed(2)}`;
            });
        });
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('gpa_to_cgpa_converter', 'gpa_to_cgpa_converter_shortcode');

function gpa_to_cgpa_converter_styles() {
    ?>
    <style>
        /* General Styles */
        #gpa-to-cgpa-converter {
            width: 100%;
            margin: 0 auto;
            padding: 20px;
            border-radius: 8px;
            background: #F2F9FF;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
	#gpa-to-cgpa-converter h2 {
    	  color: #00335A;
          text-align: center;
       }
        #converter-form {
            display: flex;
            flex-direction: column;
	    margin-top: 16px;
        }
        .gpa-field {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }
        #gpa-fields{
	   margin-top: 14px;
	}
        .gpa-field label {
            font-weight: bold;
            margin-right: 10px;
            width: 30%;
            text-align: right;
            color: #00335A;
        }
        .gpa-field input {
            padding: 10px;
            font-size: 1em;
            margin-right: 10px;
            border: 1px solid #00477D;
            border-radius: 4px;
            width: 50%;
            color: #00335A;
            background-color: #D9ECFF;
        }

        .button-row {
            /*display: flex;*/
            justify-content: space-between;
            margin-top: 20px;
        }
        .button-row button {
            padding: 12px 20px;
            font-size: 1em;
            color: #fff;
            background-color: #00477D;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button-row button:hover {
            background-color: #002655;
        }
        button.remove-field {
             width: 20%;
             background-color: #C0392B;
        }

        button.remove-field : hover {
             background-color: #A72B21;
        }        
        #result-label {
            margin-top: 20px;
            color: #00335A;
            font-weight: bold;
        }
        #cgpa-result {
            width: 100%;
            font-weight: bold;
            background-color: #D9ECFF;
            padding: 10px;
            color: #00335A;
            border-radius: 4px;
            border: 1px solid #00477D;
            transition: background-color 0.3s;
        }

        #empty-div {
            width: 22%;
        }

        /* Responsive Styles */
        @media (max-width: 1080px) {
            #gpa-to-cgpa-converter {
                padding: 15px;
                max-width: 100%;
            }
            .gpa-field {
                flex-direction: column;
                align-items: flex-start;
            }
            .gpa-field label {
                width: 100%;
                text-align: left;
                margin-bottom: 5px;
            }
            .gpa-field input {
                width: 100%;
                margin-right: 0;
                margin-bottom: 10px;
            }
            .gpa-field .remove-field {
                align-self: flex-end;
                border: none;
                color: white;
                padding: 5px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin-top: 6px;
            }
            .button-row {
                justify-content: space-between;
                margin-top: 10px;
            }
            .button-row button {
                width: 100%;
                margin-bottom: 10px;
            }
        }

        @media (max-width: 768px) {
            .gpa-field {
                flex-direction: column;
                align-items: flex-start;
            }
            .gpa-field label {
                width: 100%;
                margin-right: 0;
                margin-bottom: 5px;
                text-align: left;
            }
            .gpa-field input {
                width: 100%;
                margin-right: 0;
                margin-bottom: 10px;
            }
            .gpa-field .remove-field {
                align-self: flex-end;
                border: none;
                color: white;
                padding: 5px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin-top: 8px;
            }
            .button-row button {
                width: 100%;
                margin-bottom: 10px;
            }
            button.remove-field {
                width: 25%;
            }
        }

        @media (max-width: 600px) {
            .gpa-field {
                flex-direction: column;
                align-items: flex-start;
            }
            .gpa-field label {
                width: 100%;
                margin-right: 0;
                margin-bottom: 5px;
                text-align: left;
            }
            .gpa-field input {
                width: 100%;
                margin-right: 0;
                margin-bottom: 10px;
            }
            .gpa-field .remove-field {
                align-self: flex-end;
                background: #d9534f;
                border: none;
                color: white;
                padding: 5px 10px;
                cursor: pointer;
                border-radius: 4px;
                margin-top: 8px;
            }
            .button-row button {
                width: 100%;
                margin-bottom: 10px;
            }
            button.remove-field {
                width: 40%;
            }
        }
    </style>
    <?php
}
add_action('wp_head', 'gpa_to_cgpa_converter_styles');
